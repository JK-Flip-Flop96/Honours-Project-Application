package com.honours.project

import android.content.Intent
import android.location.Location
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.honours.project.models.Report
import kotlinx.android.synthetic.main.fragment_main.*


// Log Tag
private const val TAG = "MapFragment"

private const val KEY_CAMERA_POSITION = "camera_position"
private const val KEY_LOCATION = "location"
private const val MAPVIEW_BUNDLE_KEY = "MapViewBundleKey"

private const val DEFAULT_ZOOM: Float = 17.0F

class MapsFragment : Fragment(), OnMapReadyCallback {

    // Activities
    private lateinit var mFrgAct: NavActivity
    private lateinit var mIntent: Intent

    // Views
    private lateinit var mMap: GoogleMap

    // Map Defaults
    private var reports: MutableList<Report> = mutableListOf()

    private val mDefaultLocation = LatLng(0.0, 0.0)

    private var mCurrentLocation: Parcelable? = null
    private var mLastKnownLocation: Location? = null

    private var mCameraPosition: CameraPosition? = null

    // Location Provider
    private lateinit var mFusedLocationProviderClient: FusedLocationProviderClient

    /**
     * onCreateView
     */
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var mapViewBundle: Bundle? = null

        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAPVIEW_BUNDLE_KEY)
            mCurrentLocation = savedInstanceState.getParcelable(KEY_LOCATION)
            mCameraPosition = savedInstanceState.getParcelable(KEY_CAMERA_POSITION)
        }

        val view = inflater.inflate(R.layout.fragment_main, container, false)

        val m = view.findViewById<MapView>(R.id.map)
        m.onCreate(mapViewBundle)
        m.getMapAsync(this)

        return view
    }

    /**
     * onViewCreated
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.i(TAG, "Map Fragment Created")

        /*
            MAP SETUP
         */
        // Construct a FusedLocationProviderClient.
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(
            requireActivity()
        )
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mFrgAct = requireActivity() as NavActivity
        mIntent = mFrgAct.intent
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        var mapViewBundle: Bundle? = outState.getBundle(MAPVIEW_BUNDLE_KEY)
        if(mapViewBundle == null) {
            mapViewBundle = Bundle()
            outState.putBundle(MAPVIEW_BUNDLE_KEY, mapViewBundle)
        }

        map.onSaveInstanceState(mapViewBundle)
        outState.putParcelable(KEY_CAMERA_POSITION, mMap.cameraPosition)
        outState.putParcelable(KEY_LOCATION, mLastKnownLocation)
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onStart() {
        super.onStart()
        map.onStart()
    }

    override fun onStop() {
        super.onStop()
        map.onStop()
    }

    /**
     * Callback when the map is ready for use
     */
    override fun onMapReady(googleMap: GoogleMap) {
        try {
            MapsInitializer.initialize(this.activity)
        } catch (e: GooglePlayServicesNotAvailableException) {
            e.printStackTrace()
        }

        mMap = googleMap

        //Load the Map Style
        mMap.setMapStyle(MapStyleOptions(resources.getString(R.string.style_json)))

        mMap.uiSettings.isMapToolbarEnabled = false
        mMap.uiSettings.isCompassEnabled = false

        // Populate the Map with nearby markers
        for (report in reports) {
            //TODO Do this for real
            mMap.addMarker(MarkerOptions().position(LatLng(report.lat, report.long)))
        }

        // Set onClickListener for the Floating Action Button
        fab.setOnClickListener {
            getDeviceLocation()
            mFrgAct.onFabClick(mLastKnownLocation!!)
        }

        // Attempt to get the device's location
        updateLocationUI()
        getDeviceLocation()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        map.onStop()
        super.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        map.onLowMemory()
    }

    private fun updateLocationUI() {
        try {
            if (mFrgAct.mLocationPermissionGranted) {
                mMap.isMyLocationEnabled = true
                mMap.uiSettings.isMyLocationButtonEnabled = true
            } else {
                mMap.isMyLocationEnabled = false
                mMap.uiSettings.isMyLocationButtonEnabled = false
                mLastKnownLocation = null
                mFrgAct.getLocationPermission()
            }
        } catch (e: SecurityException) {

        }
    }

    private fun getDeviceLocation() {
        try {
            if (mFrgAct.mLocationPermissionGranted) {
                Log.i(TAG, "Location Access Approved")
                mFusedLocationProviderClient.lastLocation.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.i(TAG, "Location Accessed")
                        mLastKnownLocation = task.result as Location
                        mMap.moveCamera(
                            CameraUpdateFactory.newCameraPosition(
                                CameraPosition.Builder().target(
                                    LatLng(
                                        mLastKnownLocation!!.latitude,
                                        mLastKnownLocation!!.longitude
                                    )
                                ).zoom(DEFAULT_ZOOM).tilt(40f).build()
                            )
                        )
                    } else {
                        Log.i(TAG, "Location Failed")
                        mMap.moveCamera(
                            CameraUpdateFactory.newLatLngZoom(
                                mDefaultLocation, DEFAULT_ZOOM
                            )
                        )
                        mMap.uiSettings.isMyLocationButtonEnabled = false
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "Get Location Function Failed")
        }
    }
}

