package com.honours.project

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.icu.text.SimpleDateFormat
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.Toast
import com.google.android.material.navigation.NavigationView
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.GravityCompat
import androidx.navigation.NavController
import com.firebase.ui.auth.AuthUI
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import com.honours.project.models.Report
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_nav.*
import java.io.File
import java.io.IOException
import java.util.*


private const val TAG = "NavActivity"

// Request parameters
private const val REQUEST_IMAGE_CAPTURE = 1

private const val PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 101
private const val PERMISSIONS_REQUEST_ACCESS_CAMERA = 102

private const val AUTH_REQUEST_SIGN_IN = 201

class NavActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var navController: NavController
    private lateinit var navView: NavigationView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var menu: Menu

    // Firebase Auth
    private lateinit var auth: FirebaseAuth
    private lateinit var uid: String
    private var signedIn = false

    // Firebase Storage
    private lateinit var storage: FirebaseStorage
    private lateinit var imageRef: StorageReference
    private lateinit var currentPhotoPath: String

    // Firebase Database
    private lateinit var database: FirebaseDatabase
    private lateinit var dataRef: DatabaseReference
    private lateinit var dataImageRef: DatabaseReference
    private lateinit var dataUserRef: DatabaseReference
    private var userScore = 0L
    private lateinit var location: Location

    // Permissions Checks
    var mLocationPermissionGranted: Boolean = false
    private var mCameraPermissionGranted: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nav)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawer_layout)
        navView = nav_view
        navController = findNavController(R.id.nav_host_fragment)

        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        menu = navView.menu

        /*
            SIGN IN
        */
        auth = FirebaseAuth.getInstance()
        val current = auth.currentUser
        signedIn = current != null

        /*
            STORAGE SETUP
         */
        // Get the firebase storage object
        storage = Firebase.storage

        // Get a reference for the images folder
        imageRef = storage.reference.child("images")

        /*
            DATABASE SETUP
         */
        // Get the firebase database object
        database = Firebase.database

        // Get a references to locations in the database database
        dataRef = database.reference
        dataImageRef = dataRef.child("images")
        dataUserRef = dataRef.child("users")

        // Listener for checking the user's score
        val listener = object : ValueEventListener {
            override fun onDataChange(p0: DataSnapshot) {

                if (p0.exists())
                // If the user has a score store the value locally
                    userScore = p0.value as Long
                else
                // If the user has no score set it to 0
                    dataUserRef.child(uid).setValue(userScore)
            }

            override fun onCancelled(p0: DatabaseError) {
                Log.e(TAG, "Database Retrieve Cancelled")
            }
        }

        // Get the uid and score of the user if they are signed in
        if (signedIn) {
            // Update the UI to reflect signed in status
            onSignIn(false)

            // Use the listener to get the score
            dataUserRef.child(uid).addListenerForSingleValueEvent(listener)
        } else {
            // Update the UI to reflect signed out status
            onSignOut(false)
        }

        /*
            PERMISSIONS CHECKS
         */
        getLocationPermission()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.settings_menu, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }



    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_leaderboard -> {
                navController.navigate(R.id.action_MapFragment_to_LeaderboardFragment)
            }
            R.id.nav_contributions -> {
                navController.navigate(R.id.action_MapFragment_to_ContributionsFragment)
            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    /**
     * Begins signing the in out when the menu item is clicked
     */
    fun onSignInClick(item: MenuItem) {
        Log.i(TAG, "Attempt to Sign In")
        startActivityForResult(
            AuthUI.getInstance()
                .createSignInIntentBuilder()
                .setAvailableProviders(
                    arrayListOf(AuthUI.IdpConfig.GoogleBuilder().build())).build()
            , AUTH_REQUEST_SIGN_IN
        )
    }

    /**
     * Handles changes required when the user successfully signs in
     */
    private fun onSignIn(inform: Boolean) {
        Log.i(TAG, "Successfully Signed In")
        signedIn = true
        uid = auth.uid!!

        if(inform)
            makeToast("Signed In")

        menu.setGroupVisible(R.id.nav_group_logged_in, true)
        menu.setGroupVisible(R.id.nav_group_logged_out, false)

        //TODO (Get the proper image)
        Picasso.get().load(auth.currentUser!!.photoUrl)
            .into(navView.getHeaderView(0).findViewById<ImageView>(R.id.nav_imageView))
    }

    /**
     * Begins signing the user out when the menu item is clicked
     */
    fun onSignOutClick(item: MenuItem) {
        // Sign out from the application
        Log.i(TAG, "Attempt to Sign Out")
        AuthUI.getInstance().signOut(this)
            .addOnSuccessListener {
                onSignOut(true)
            }
            .addOnFailureListener {
                Log.e(TAG, "Attempt to Sign Out Failed")
                makeToast("Sign Out Failed")
            }
    }

    /**
     * Deletes all data associated with the user
     */
    fun onDeleteUserClick(item: MenuItem) {
        // Sign out from the application
        Log.i(TAG, "Attempt to Delete All Data")
        AuthUI.getInstance().delete(this)
            .addOnSuccessListener {

            }
            .addOnFailureListener {
                Log.e(TAG, "Attempt to Delete All Data Failed")
                makeToast("Delete Failed")
            }
    }

    /**
     * Handles changes required when the user successfully signs out
     */
    private fun onSignOut(inform: Boolean) {
        Log.i(TAG, "Successfully Signed Out")

        signedIn = false
        uid = null.toString()

        if(inform) {
            makeToast("Signed Out")
        }

        menu.setGroupVisible(R.id.nav_group_logged_in, false)
        menu.setGroupVisible(R.id.nav_group_logged_out, true)
    }

    // =========================== PERMISSIONS METHODS =======================================

    /**
     * Function to check if the application has location access
     */
    fun getLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            == PackageManager.PERMISSION_GRANTED
        ) {
            //If location permission is granted
            Log.i(TAG, "Location Permission Granted")
            mLocationPermissionGranted = true
        } else {
            //If location permission is not granted, request it.
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION
            )
            Log.i(TAG, "Location Permission Missing")
        }
    }

    /**
     * Listener for the return of permission requests
     */
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when (requestCode) {
            PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION -> {
                if (grantResults.isNotEmpty() && grantResults[0] ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    mLocationPermissionGranted = true
                }
            }
            PERMISSIONS_REQUEST_ACCESS_CAMERA -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    mCameraPermissionGranted = true
                }
            }
        }
    }

    // AUXILIARY METHODS
    /**
     * Make a toast message appear with the passed in string
     */
    private fun makeToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    fun onFabClick(loc: Location){
        location = loc
        dispatchTakePictureIntent()
    }

    private fun onPictureSuccess(data: Intent?) {
        Log.i(TAG, "picture returned")
        // BottomDialogFragment().newInstance(imageBitmap).show(supportFragmentManager, "dialog")

        // If successful, upload the information to the cloud
        if (true) {
            // Get the description from the dialog
            val description = ""

            // Extract the Latitude and Longitude
            val lat = location.latitude
            val long = location.longitude

            // Generate the Marker
            val options = MarkerOptions().position(LatLng(lat, long))

            // Add the Marker
            //mMap.addMarker(options)

            // Upload the photo
            val file = Uri.fromFile(File(currentPhotoPath))
            val refToImage = "images/${file.lastPathSegment}"
            val ref = imageRef.child(refToImage)
            val uploadTask = ref.putFile(file)

            // Add status Listeners to the upload task
            uploadTask.addOnFailureListener {
                Log.e(TAG, "Error Uploading Photo")
            }.addOnSuccessListener {
                Log.i(TAG, "Photo Uploaded")

                // Once the image has successfully been upload proceed to update the database
                dataRef.child("reports")
                    .child(
                        uid + "_" + SimpleDateFormat("yyyyMMdd_HHmmss")
                            .format(Date())
                    ).setValue(
                        Report(
                            uid,
                            lat,
                            long,
                            refToImage,
                            description
                        )
                    )

                // Update the user's score
                userScore += 10
                if (description != "") {
                    userScore += 20
                }
                dataUserRef.child(uid).setValue(userScore)
            }
        }
    }



    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(this.packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    Log.e(TAG, "Image File Creation Failed")
                    null
                }

                // Proceed only if photo file was successfully created.
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(this,
                        "com.honours.project.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            onPictureSuccess(data)
        } else if (requestCode == AUTH_REQUEST_SIGN_IN && resultCode == Activity.RESULT_OK) {
            onSignIn(true)
        }
    }

    override fun onBackPressed() {
        if (this.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
