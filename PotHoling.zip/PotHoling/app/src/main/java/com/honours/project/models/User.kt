package com.honours.project.models

data class User(
    var uid: String
)

